import sendmsg
import recvmsg
sendmsg.test1()
sendmsg.test2()
recvmsg.test1()


#from sendmsg import test1,test2
#from sendmsg import test2

#from sendmsg import *
#from recvmsg import *

#test1()
#test2()
