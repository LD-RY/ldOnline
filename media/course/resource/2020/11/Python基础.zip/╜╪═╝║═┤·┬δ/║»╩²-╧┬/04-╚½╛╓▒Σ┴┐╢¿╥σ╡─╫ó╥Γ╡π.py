
a = 100
b = 200
c = 300

def test():
    print("a=%d"%a)
    print("b=%d"%b)
    print("c=%d"%c)

#b = 200

test()

#c = 300#有问题
