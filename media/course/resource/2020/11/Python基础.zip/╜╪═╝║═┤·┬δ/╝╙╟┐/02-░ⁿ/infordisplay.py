def test3():
    print("-----infordisplay-test3----")
