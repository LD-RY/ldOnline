#1. 打印功能提示
print("="*50)
print("   名片管理系统 V0.01")
print(" 1. 添加一个新的名片")
print(" 2. 删除一个名片")
print(" 3. 修改一个名片")
print(" 4. 查询一个名片")
print(" 5. 退出系统")
print("="*50)

while True:

    #2. 获取用户的输入
    num = int(input("请输入操作序号:"))

    #3. 根据用户的数据执行相应的功能
    if num==1:
        pass
    elif num==2:
        pass
    elif num==3:
        pass
    elif num==4:
        pass
    elif num==5:
        pass
    else:
        print("输入有误,请重新输入")
