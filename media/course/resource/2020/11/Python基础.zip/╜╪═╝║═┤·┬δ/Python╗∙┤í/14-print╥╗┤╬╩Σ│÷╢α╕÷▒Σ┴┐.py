name = "laowang"
age = 20
addr = "山东....."

print("姓名是:%s, 年龄是:%d,地址是:%s"%(name, age, addr))
