ls
pwd
ls /
