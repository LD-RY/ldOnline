high = input("请输入你的身高:")
