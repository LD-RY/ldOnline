f = open("xxx.txt","w")

f.write("hahaha")

f.close()
